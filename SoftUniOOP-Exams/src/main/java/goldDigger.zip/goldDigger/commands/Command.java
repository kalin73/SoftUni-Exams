package goldDigger.commands;

public interface Command {
	String execute();
}
