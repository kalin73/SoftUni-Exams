package goldDigger.models.discoverer;

public class Anthropologist extends BaseDiscoverer {
	private static double initialEnergy = 40;

	public Anthropologist(String name) {
		super(name, initialEnergy);
	}

}
