package goldDigger.core;

public interface Engine extends Runnable{

}
