package football.entities.field;

public class NaturalGrass extends BaseField {

	private static final int DEFAULT_CAPACITY = 250;

	public NaturalGrass(String name) {
		super(name, DEFAULT_CAPACITY);
	}
}
